package org.levimc.launcher.ui.views;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import org.levimc.launcher.R;

import java.util.ArrayList;
import java.util.List;

/**
 * Draws a rotating 3D Minecraft player model from a 64x64 (or 64x32, or HD multiples) skin PNG.
 * Every box face is a textured quad drawn with a projective matrix, back-face culled and depth sorted.
 * Drag horizontally to rotate.
 */
public class Skin3DView extends View {

    private static final float CAM_DISTANCE = 90f;

    private static final class Face {
        Bitmap tex;
        final float[] p = new float[12]; // TL, TR, BR, BL (x, y, z each)
        float bias;
    }

    private static final class Visible {
        Face face;
        final float[] screen = new float[8];
        float depth;
    }

    private Bitmap skin;
    private Bitmap defaultSkin;
    private final List<Face> faces = new ArrayList<>();
    private final List<Visible> pool = new ArrayList<>();
    private final Paint paint = new Paint();
    private final Matrix matrix = new Matrix();
    private final float[] srcPts = new float[8];
    private final float[] rot = new float[12];

    private float yaw = 28f;
    private float pitch = 8f;
    private boolean autoRotate = true;
    private boolean dragging = false;
    private float lastX;
    private long lastFrame = 0L;

    public Skin3DView(Context context) {
        super(context);
        init();
    }

    public Skin3DView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public Skin3DView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        paint.setFilterBitmap(false);
        paint.setAntiAlias(false);
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inScaled = false;
        defaultSkin = BitmapFactory.decodeResource(getResources(), R.drawable.default_skin, o);
        rebuild();
    }

    /** Pass null to go back to the built-in starting skin. */
    public void setSkin(Bitmap bmp) {
        this.skin = bmp;
        rebuild();
        invalidate();
    }

    public void setAutoRotate(boolean on) {
        this.autoRotate = on;
    }

    private void rebuild() {
        faces.clear();
        Bitmap s = skin != null ? skin : defaultSkin;
        if (s == null || s.getWidth() < 64) return;
        float sc = s.getWidth() / 64f;
        boolean legacy = s.getHeight() < s.getWidth();
        boolean slim = !legacy && isSlim(s, sc);
        float aw = slim ? 3f : 4f;

        // head (+ hat)
        addBox(s, sc, 0, 0, 8, 8, 8, 0f, 28f, 0f, false, 0f);
        addBox(s, sc, 32, 0, 8, 8, 8, 0f, 28f, 0f, true, 0.5f);
        // body (+ jacket)
        addBox(s, sc, 16, 16, 8, 12, 4, 0f, 18f, 0f, false, 0f);
        if (!legacy) addBox(s, sc, 16, 32, 8, 12, 4, 0f, 18f, 0f, true, 0.25f);
        // right arm (viewer's left)
        float rax = -(4f + aw / 2f);
        addBox(s, sc, 40, 16, (int) aw, 12, 4, rax, 18f, 0f, false, 0f);
        if (!legacy) addBox(s, sc, 40, 32, (int) aw, 12, 4, rax, 18f, 0f, true, 0.25f);
        // left arm
        float lax = 4f + aw / 2f;
        if (legacy) {
            addBox(s, sc, 40, 16, (int) aw, 12, 4, lax, 18f, 0f, false, 0f);
        } else {
            addBox(s, sc, 32, 48, (int) aw, 12, 4, lax, 18f, 0f, false, 0f);
            addBox(s, sc, 48, 48, (int) aw, 12, 4, lax, 18f, 0f, true, 0.25f);
        }
        // right leg
        addBox(s, sc, 0, 16, 4, 12, 4, -2f, 6f, 0f, false, 0f);
        if (!legacy) addBox(s, sc, 0, 32, 4, 12, 4, -2f, 6f, 0f, true, 0.25f);
        // left leg
        if (legacy) {
            addBox(s, sc, 0, 16, 4, 12, 4, 2f, 6f, 0f, false, 0f);
        } else {
            addBox(s, sc, 16, 48, 4, 12, 4, 2f, 6f, 0f, false, 0f);
            addBox(s, sc, 0, 48, 4, 12, 4, 2f, 6f, 0f, true, 0.25f);
        }
    }

    private boolean isSlim(Bitmap s, float sc) {
        int x = Math.round(47 * sc);
        int y0 = Math.round(20 * sc);
        int y1 = Math.round(32 * sc);
        if (x >= s.getWidth() || y1 > s.getHeight()) return false;
        for (int y = y0; y < y1; y++) {
            if (Color.alpha(s.getPixel(x, y)) != 0) return false;
        }
        return true;
    }

    private void addBox(Bitmap s, float sc, int u, int v, int w, int h, int d,
                        float cx, float cy, float cz, boolean overlay, float grow) {
        float hx = w / 2f + grow;
        float hy = h / 2f + grow;
        float hz = d / 2f + grow;
        float bias = overlay ? 0.3f : 0f;
        // front
        face(s, sc, u + d, v + d, w, h, bias,
                cx - hx, cy + hy, cz + hz, cx + hx, cy + hy, cz + hz,
                cx + hx, cy - hy, cz + hz, cx - hx, cy - hy, cz + hz);
        // back
        face(s, sc, u + 2 * d + w, v + d, w, h, bias,
                cx + hx, cy + hy, cz - hz, cx - hx, cy + hy, cz - hz,
                cx - hx, cy - hy, cz - hz, cx + hx, cy - hy, cz - hz);
        // right (player's right = viewer's left when facing the viewer)
        face(s, sc, u, v + d, d, h, bias,
                cx - hx, cy + hy, cz - hz, cx - hx, cy + hy, cz + hz,
                cx - hx, cy - hy, cz + hz, cx - hx, cy - hy, cz - hz);
        // left
        face(s, sc, u + d + w, v + d, d, h, bias,
                cx + hx, cy + hy, cz + hz, cx + hx, cy + hy, cz - hz,
                cx + hx, cy - hy, cz - hz, cx + hx, cy - hy, cz + hz);
        // top
        face(s, sc, u + d, v, w, d, bias,
                cx - hx, cy + hy, cz - hz, cx + hx, cy + hy, cz - hz,
                cx + hx, cy + hy, cz + hz, cx - hx, cy + hy, cz + hz);
        // bottom
        face(s, sc, u + d + w, v, w, d, bias,
                cx - hx, cy - hy, cz + hz, cx + hx, cy - hy, cz + hz,
                cx + hx, cy - hy, cz - hz, cx - hx, cy - hy, cz - hz);
    }

    private void face(Bitmap s, float sc, int tx, int ty, int tw, int th, float bias,
                      float x0, float y0, float z0, float x1, float y1, float z1,
                      float x2, float y2, float z2, float x3, float y3, float z3) {
        int px = Math.round(tx * sc);
        int py = Math.round(ty * sc);
        int pw = Math.max(1, Math.round(tw * sc));
        int ph = Math.max(1, Math.round(th * sc));
        if (px < 0 || py < 0 || px + pw > s.getWidth() || py + ph > s.getHeight()) return;
        Face f = new Face();
        f.tex = Bitmap.createBitmap(s, px, py, pw, ph);
        f.bias = bias;
        float[] p = f.p;
        p[0] = x0; p[1] = y0; p[2] = z0;
        p[3] = x1; p[4] = y1; p[5] = z1;
        p[6] = x2; p[7] = y2; p[8] = z2;
        p[9] = x3; p[10] = y3; p[11] = z3;
        faces.add(f);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        int w = getWidth();
        int h = getHeight();
        if (w <= 0 || h <= 0 || faces.isEmpty()) return;

        long now = SystemClock.uptimeMillis();
        if (lastFrame != 0L && autoRotate && !dragging) {
            yaw += (now - lastFrame) * 0.03f;
        }
        lastFrame = now;

        double ry = Math.toRadians(yaw);
        double rx = Math.toRadians(pitch);
        float cyaw = (float) Math.cos(ry);
        float syaw = (float) Math.sin(ry);
        float cp = (float) Math.cos(rx);
        float sp = (float) Math.sin(rx);

        float unit = Math.min(h * 0.94f / 34f, w * 0.92f / 20f);
        float focal = unit * CAM_DISTANCE;
        float midX = w / 2f;
        float midY = h / 2f;

        int count = 0;
        for (Face f : faces) {
            for (int i = 0; i < 4; i++) {
                float x = f.p[i * 3];
                float y = f.p[i * 3 + 1] - 17f;
                float z = f.p[i * 3 + 2];
                float x1 = x * cyaw + z * syaw;
                float z1 = -x * syaw + z * cyaw;
                float y2 = y * cp - z1 * sp;
                float z2 = y * sp + z1 * cp;
                rot[i * 3] = x1;
                rot[i * 3 + 1] = y2;
                rot[i * 3 + 2] = z2;
            }
            // outward normal = (BL - TL) x (TR - TL)
            float ax = rot[9] - rot[0], ay = rot[10] - rot[1], az = rot[11] - rot[2];
            float bx = rot[3] - rot[0], by = rot[4] - rot[1], bz = rot[5] - rot[2];
            float nx = ay * bz - az * by;
            float ny = az * bx - ax * bz;
            float nz = ax * by - ay * bx;
            float ccx = (rot[0] + rot[3] + rot[6] + rot[9]) / 4f;
            float ccy = (rot[1] + rot[4] + rot[7] + rot[10]) / 4f;
            float ccz = (rot[2] + rot[5] + rot[8] + rot[11]) / 4f;
            float dot = nx * (0f - ccx) + ny * (0f - ccy) + nz * (CAM_DISTANCE - ccz);
            float nlen = (float) Math.sqrt(nx * nx + ny * ny + nz * nz);
            float dist = (float) Math.sqrt(ccx * ccx + ccy * ccy + (CAM_DISTANCE - ccz) * (CAM_DISTANCE - ccz));
            // cull back faces and faces seen (almost) exactly edge-on
            if (nlen < 1e-6f || dot <= 0.02f * nlen * dist) continue;

            Visible v;
            if (count < pool.size()) {
                v = pool.get(count);
            } else {
                v = new Visible();
                pool.add(v);
            }
            count++;
            v.face = f;
            v.depth = ccz + f.bias;
            for (int i = 0; i < 4; i++) {
                float d = CAM_DISTANCE - rot[i * 3 + 2];
                float k = focal / d;
                v.screen[i * 2] = midX + rot[i * 3] * k;
                v.screen[i * 2 + 1] = midY - rot[i * 3 + 1] * k;
            }
        }

        // far to near (insertion sort, ascending z = farther first)
        for (int i = 1; i < count; i++) {
            Visible key = pool.get(i);
            int j = i - 1;
            while (j >= 0 && pool.get(j).depth > key.depth) {
                pool.set(j + 1, pool.get(j));
                j--;
            }
            pool.set(j + 1, key);
        }

        for (int i = 0; i < count; i++) {
            Visible v = pool.get(i);
            Bitmap t = v.face.tex;
            srcPts[0] = 0; srcPts[1] = 0;
            srcPts[2] = t.getWidth(); srcPts[3] = 0;
            srcPts[4] = t.getWidth(); srcPts[5] = t.getHeight();
            srcPts[6] = 0; srcPts[7] = t.getHeight();
            matrix.reset();
            if (!matrix.setPolyToPoly(srcPts, 0, v.screen, 0, 4)) continue;
            canvas.save();
            canvas.concat(matrix);
            canvas.drawBitmap(t, 0f, 0f, paint);
            canvas.restore();
        }

        if (isShown()) postInvalidateOnAnimation();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                dragging = true;
                lastX = e.getX();
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                return true;
            case MotionEvent.ACTION_MOVE:
                yaw += (e.getX() - lastX) * 0.6f;
                lastX = e.getX();
                invalidate();
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                dragging = false;
                lastFrame = SystemClock.uptimeMillis();
                return true;
            default:
                return super.onTouchEvent(e);
        }
    }
}
