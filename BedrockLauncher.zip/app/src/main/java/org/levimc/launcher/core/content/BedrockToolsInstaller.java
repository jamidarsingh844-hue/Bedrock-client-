package org.levimc.launcher.core.content;

import android.content.Context;
import android.util.Log;

import org.levimc.launcher.core.mods.ModManager;
import org.levimc.launcher.core.versions.GameVersion;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** Installs the bundled BedrockTools mod pack (Fullbright and more) into the selected version's mods folder. */
public final class BedrockToolsInstaller {
    private static final String TAG = "BedrockToolsInstaller";
    private static final String ASSET = "BedrockTools.levipack";
    private static final String FOLDER = "BedrockTools";
    private static final String LIB = "libBedrockTools.so";

    private BedrockToolsInstaller() {}

    public static void ensureInstalled(Context context, GameVersion version) {
        if (version == null || version.modsDir == null) return;
        try {
            File modsDir = version.modsDir;
            if (!modsDir.exists()) modsDir.mkdirs();
            File dest = new File(modsDir, FOLDER);
            if (new File(dest, LIB).isFile() && new File(dest, "manifest.json").isFile()) return;
            extract(context, dest);
            try {
                ModManager.getInstance().reloadMods();
            } catch (Throwable t) {
                Log.w(TAG, "reloadMods failed: " + t.getMessage());
            }
            Log.i(TAG, "Installed BedrockTools to " + dest.getAbsolutePath());
        } catch (Throwable t) {
            Log.w(TAG, "BedrockTools install failed: " + t.getMessage());
        }
    }

    private static void extract(Context context, File dest) throws Exception {
        if (!dest.exists() && !dest.mkdirs()) throw new java.io.IOException("Cannot create " + dest);
        String destPath = dest.getCanonicalPath() + File.separator;
        byte[] buf = new byte[32768];
        try (InputStream raw = context.getAssets().open(ASSET);
             ZipInputStream zin = new ZipInputStream(raw)) {
            ZipEntry e;
            while ((e = zin.getNextEntry()) != null) {
                if (e.isDirectory()) continue;
                File out = new File(dest, e.getName());
                if (!out.getCanonicalPath().startsWith(destPath)) continue;
                File parent = out.getParentFile();
                if (parent != null && !parent.exists()) parent.mkdirs();
                try (OutputStream os = new FileOutputStream(out)) {
                    int n;
                    while ((n = zin.read(buf)) > 0) os.write(buf, 0, n);
                }
            }
        }
    }
}
