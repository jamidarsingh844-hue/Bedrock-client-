package org.levimc.launcher.core.content;

import android.content.Context;
import android.util.Log;

import org.levimc.launcher.core.versions.GameVersion;
import org.levimc.launcher.util.LauncherStorage;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** Keeps the bundled 4D skin pack installed in the game's skin_packs folder (internal and external game data). */
public final class FourDSkinInstaller {
    private static final String TAG = "FourDSkinInstaller";
    private static final String ASSET = "4d_skins.zip";
    private static final String FOLDER = "Zombie_Cosmetics_4D";
    private static final String MARKER = ".installed_v1";

    private FourDSkinInstaller() {}

    public static void ensureInstalled(Context context, GameVersion version) {
        if (version == null) return;
        for (boolean external : new boolean[]{false, true}) {
            try {
                File gameData = LauncherStorage.getStorageGameDataDir(
                        context, version.getStorageProfileId(), version.versionIsolation, external);
                if (gameData == null) continue;
                File dest = new File(new File(gameData, "skin_packs"), FOLDER);
                if (new File(dest, MARKER).exists()) continue;
                extract(context, dest);
                Log.i(TAG, "Installed 4D skin pack to " + dest.getAbsolutePath());
            } catch (Throwable t) {
                Log.w(TAG, "4D skin pack install failed (external=" + external + "): " + t.getMessage());
            }
        }
    }

    private static void extract(Context context, File dest) throws Exception {
        if (!dest.exists() && !dest.mkdirs()) throw new java.io.IOException("Cannot create " + dest);
        String destPath = dest.getCanonicalPath() + File.separator;
        byte[] buf = new byte[65536];
        try (InputStream raw = context.getAssets().open(ASSET);
             ZipInputStream zin = new ZipInputStream(raw)) {
            ZipEntry e;
            while ((e = zin.getNextEntry()) != null) {
                if (e.isDirectory()) continue;
                String name = e.getName().replace('\\', '/');
                int slash = name.indexOf('/');
                String rel = slash >= 0 ? name.substring(slash + 1) : name;
                if (rel.isEmpty()) continue;
                File out = new File(dest, rel);
                if (!out.getCanonicalPath().startsWith(destPath)) continue; // zip-slip guard
                File parent = out.getParentFile();
                if (parent != null && !parent.exists()) parent.mkdirs();
                try (OutputStream os = new FileOutputStream(out)) {
                    int n;
                    while ((n = zin.read(buf)) > 0) os.write(buf, 0, n);
                }
            }
        }
        new File(dest, MARKER).createNewFile();
    }
}
