package org.levimc.launcher.core.content;

/** Compares pack versions like "1.6.1" (pure Java, no Android dependency). */
public final class PackVersion {
    private PackVersion() {}

    public static int[] parse(String v) {
        if (v == null || v.trim().isEmpty()) return new int[]{0};
        String[] parts = v.trim().split("\\.");
        int[] out = new int[parts.length];
        for (int i = 0; i < parts.length; i++) {
            try {
                out[i] = Integer.parseInt(parts[i].trim());
            } catch (NumberFormatException e) {
                out[i] = 0;
            }
        }
        return out;
    }

    /** @return &gt;0 if a is newer than b, 0 if equal, &lt;0 if older. */
    public static int compare(String a, String b) {
        int[] x = parse(a), y = parse(b);
        int n = Math.max(x.length, y.length);
        for (int i = 0; i < n; i++) {
            int xi = i < x.length ? x[i] : 0;
            int yi = i < y.length ? y[i] : 0;
            if (xi != yi) return Integer.compare(xi, yi);
        }
        return 0;
    }
}
