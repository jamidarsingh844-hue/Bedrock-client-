package org.levimc.launcher.core.content;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.util.Log;

import org.json.JSONObject;
import org.levimc.launcher.core.versions.GameVersion;
import org.levimc.launcher.settings.FeatureSettings;
import org.levimc.launcher.util.LauncherStorage;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipInputStream;

/**
 * Keeps a list of pack files the user picked (zip / mcpack / mcaddon). At every launch each saved file is
 * imported into the game if the game does not have its packs yet, or if the saved file is a NEWER version
 * of an installed pack (then the pack is updated in place, not deleted and reinstalled).
 */
public final class PendingPackManager {
    private static final String TAG = "PendingPackManager";
    private static final long WAIT_SECONDS = 180;

    private PendingPackManager() {}

    public static File dir(Context c) {
        File d = new File(c.getFilesDir(), "pending_packs");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    public static List<File> list(Context c) {
        File[] fs = dir(c).listFiles();
        List<File> out = new ArrayList<>();
        if (fs != null) {
            Arrays.sort(fs);
            for (File f : fs) if (f.isFile()) out.add(f);
        }
        return out;
    }

    public static boolean hasPending(Context c) {
        return !list(c).isEmpty();
    }

    public static void remove(File f) {
        if (f != null && f.exists()) f.delete();
    }

    public static File copyIn(Context c, Uri uri) throws Exception {
        String name = displayName(c, uri);
        String lower = name.toLowerCase(Locale.ROOT);
        String ext;
        if (lower.endsWith(".mcaddon")) ext = ".mcaddon";
        else if (lower.endsWith(".mcpack")) ext = ".mcpack";
        else if (lower.endsWith(".zip")) ext = ".zip";
        else throw new java.io.IOException("Unsupported file: " + name + " (use zip, mcpack or mcaddon)");
        String base = name.substring(0, name.length() - ext.length()).replaceAll("[^A-Za-z0-9._ -]", "_");
        if (base.isEmpty()) base = "pack";
        File out = new File(dir(c), base + ext);
        int n = 1;
        while (out.exists()) {
            out = new File(dir(c), base + "_" + n + ext);
            n++;
        }
        try (InputStream in = c.getContentResolver().openInputStream(uri);
             OutputStream os = new FileOutputStream(out)) {
            if (in == null) throw new java.io.IOException("Cannot open " + name);
            byte[] buf = new byte[65536];
            int r;
            while ((r = in.read(buf)) > 0) os.write(buf, 0, r);
        }
        return out;
    }

    private static String displayName(Context c, Uri uri) {
        try (Cursor cur = c.getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (cur != null && cur.moveToFirst()) {
                String n = cur.getString(0);
                if (n != null && !n.isEmpty()) return n;
            }
        } catch (Exception ignored) {
        }
        String last = uri.getLastPathSegment();
        return last == null ? "pack.zip" : last;
    }

    /** Imports every saved file whose packs are missing from the game. Call on a background thread. */
    public static String ensureImported(Context c, GameVersion v) {
        List<File> files = list(c);
        if (files.isEmpty() || v == null) return "No saved packs";
        int imported = 0, present = 0, failed = 0;
        for (boolean external : new boolean[]{false, true}) {
            try {
                File gd = LauncherStorage.getStorageGameDataDir(c, v.getStorageProfileId(), v.versionIsolation, external);
                if (gd == null) continue;
                Map<String, String> installed = installedPacks(gd);
                for (File f : files) {
                    Map<String, String> packs = packsInFile(f);
                    if (packs.isEmpty()) continue;
                    boolean needsImport = false;
                    for (Map.Entry<String, String> e : packs.entrySet()) {
                        String have = installed.get(e.getKey());
                        if (have == null || PackVersion.compare(e.getValue(), have) > 0) { needsImport = true; break; }
                    }
                    if (!needsImport) { present++; continue; }
                    if (importInto(c, f, gd)) {
                        imported++;
                        installed = installedPacks(gd);
                    } else {
                        failed++;
                    }
                }
            } catch (Throwable t) {
                Log.w(TAG, "ensureImported failed: " + t.getMessage());
                failed++;
            }
        }
        return "Saved packs: added/updated " + imported + ", already up to date " + present + (failed > 0 ? ", failed " + failed : "");
    }

    private static boolean importInto(Context c, File f, File gd) {
        new File(gd, "resource_packs").mkdirs();
        new File(gd, "behavior_packs").mkdirs();
        new File(gd, "skin_packs").mkdirs();
        final CountDownLatch latch = new CountDownLatch(1);
        final boolean[] ok = {false};
        ContentImporter importer = new ContentImporter(c);
        try {
            importer.importContent(Collections.singletonList(Uri.fromFile(f)),
                    new File(gd, "resource_packs"), new File(gd, "behavior_packs"),
                    new File(gd, "skin_packs"), new File(gd, "minecraftWorlds"),
                    new ContentImporter.ImportCallback() {
                        @Override public void onSuccess(String message) { ok[0] = true; latch.countDown(); }
                        @Override public void onError(String error) {
                            Log.w(TAG, "import error: " + error);
                            latch.countDown();
                        }
                        @Override public void onProgress(int progress) {}
                    });
            latch.await(WAIT_SECONDS, TimeUnit.SECONDS);
        } catch (Exception e) {
            Log.w(TAG, "import failed: " + e.getMessage());
        } finally {
            importer.shutdown();
        }
        return ok[0];
    }

    private static Map<String, String> installedPacks(File gd) {
        Map<String, String> out = new HashMap<>();
        for (String sub : new String[]{"resource_packs", "behavior_packs", "skin_packs"}) {
            File[] kids = new File(gd, sub).listFiles();
            if (kids == null) continue;
            for (File k : kids) {
                File mf = new File(k, "manifest.json");
                if (!mf.isFile() || mf.length() > 200000) continue;
                try (InputStream in = new java.io.FileInputStream(mf)) {
                    byte[] buf = new byte[(int) mf.length()];
                    int total = 0, r;
                    while (total < buf.length && (r = in.read(buf, total, buf.length - total)) > 0) total += r;
                    String[] uv = uuidAndVersion(new String(buf, 0, total, "UTF-8"));
                    if (uv != null) out.put(uv[0], uv[1]);
                } catch (Exception ignored) {
                }
            }
        }
        return out;
    }

    private static Map<String, String> packsInFile(File f) {
        Map<String, String> out = new HashMap<>();
        try (ZipFile zf = new ZipFile(f)) {
            Enumeration<? extends ZipEntry> en = zf.entries();
            while (en.hasMoreElements()) {
                ZipEntry e = en.nextElement();
                if (e.isDirectory()) continue;
                String name = e.getName().toLowerCase(Locale.ROOT);
                int slashes = name.length() - name.replace("/", "").length();
                if (slashes > 2) continue;
                if (name.endsWith("manifest.json")) {
                    try (InputStream in = zf.getInputStream(e)) {
                        String[] uv = uuidAndVersion(readSmall(in));
                        if (uv != null) out.put(uv[0], uv[1]);
                    }
                } else if (slashes <= 1 && (name.endsWith(".mcpack") || name.endsWith(".zip"))) {
                    try (ZipInputStream zin = new ZipInputStream(zf.getInputStream(e))) {
                        ZipEntry ne;
                        while ((ne = zin.getNextEntry()) != null) {
                            String nn = ne.getName().toLowerCase(Locale.ROOT);
                            int ns = nn.length() - nn.replace("/", "").length();
                            if (!ne.isDirectory() && ns <= 1 && nn.endsWith("manifest.json")) {
                                String[] uv = uuidAndVersion(readSmall(zin));
                                if (uv != null) out.put(uv[0], uv[1]);
                            }
                        }
                    }
                }
            }
        } catch (Exception ex) {
            Log.w(TAG, "cannot read " + f.getName() + ": " + ex.getMessage());
        }
        return out;
    }

    private static String readSmall(InputStream in) throws Exception {
        byte[] buf = new byte[65536];
        int total = 0, r;
        while (total < buf.length && (r = in.read(buf, total, buf.length - total)) > 0) total += r;
        return new String(buf, 0, total, "UTF-8");
    }

    /** @return {uuid, version like "1.6.1"} from a manifest.json text, or null. */
    private static String[] uuidAndVersion(String text) {
        try {
            if (!text.isEmpty() && text.charAt(0) == (char) 0xFEFF) text = text.substring(1);
            JSONObject h = new JSONObject(text).optJSONObject("header");
            if (h == null) return null;
            String u = h.optString("uuid", "");
            if (u.isEmpty()) return null;
            String version = "0";
            org.json.JSONArray arr = h.optJSONArray("version");
            if (arr != null) {
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < arr.length(); i++) {
                    if (i > 0) sb.append('.');
                    sb.append(arr.optInt(i, 0));
                }
                version = sb.toString();
            } else {
                String sv = h.optString("version", "");
                if (!sv.isEmpty()) version = sv;
            }
            return new String[]{u.toLowerCase(Locale.ROOT), version};
        } catch (Exception e) {
            return null;
        }
    }

    /** The game data folder the launcher's content screens use for this version (same as Import button). */
    public static File contentGameDataDir(Context c, GameVersion v) {
        SharedPreferences prefs = c.getSharedPreferences("content_management", Context.MODE_PRIVATE);
        FeatureSettings.StorageType type;
        try {
            type = FeatureSettings.StorageType.valueOf(prefs.getString("storage_type", "INTERNAL"));
        } catch (IllegalArgumentException e) {
            type = FeatureSettings.StorageType.INTERNAL;
        }
        type = LauncherStorage.normalizeContentStorageType(type, v.versionIsolation);
        return LauncherStorage.getContentGameDataDir(c, v.getStorageProfileId(), type);
    }
}
