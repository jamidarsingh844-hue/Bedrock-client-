package org.levimc.launcher.core.content.world;

import android.graphics.Color;

import java.util.Locale;

public final class MapPalette {
    private MapPalette() {}

    public static int block(String id, int biome) {
        String n = id.toLowerCase(Locale.ROOT);
        if (WorldChunk.isAir(n)) return Color.TRANSPARENT;
        if (n.startsWith("legacy:")) return 0xffA7A7A7;
        if (n.contains("diamond")) return 0xff49DFD5;
        if (n.contains("emerald")) return 0xffCA8032;
        if (n.contains("lapis")) return 0xff3C63CC;
        if (n.contains("redstone")) return 0xffC44848;
        if (n.contains("copper")) return 0xffBD825B;
        if (n.contains("gold")) return 0xffE8C957;
        if (n.contains("iron")) return 0xffBCAE9D;
        if (n.contains("coal")) return 0xff3F4147;
        if (n.contains("ancient_debris")) return 0xff97694F;
        if (n.contains("water")) return 0xff376FA4;
        if (n.contains("lava") || n.contains("fire")) return 0xffF27D2C;
        if (n.contains("snow") || n.contains("quartz") || n.contains("calcite")) return 0xffE4E6E2;
        if (n.contains("ice")) return 0xff95C6DD;
        if (n.contains("bedrock")) return 0xff3A3C42;
        if (n.contains("grass") || n.contains("fern") || n.contains("vine")) return foliage(biome);
        if (n.contains("leaves")) return shade(foliage(biome), .79f);
        if (n.contains("moss") || n.contains("azalea")) return 0xff916C46;
        if (n.contains("dirt") || n.contains("farmland") || n.contains("mud")) return 0xff8D6C4E;
        if (n.contains("mycelium")) return 0xff897184;
        if (n.contains("podzol")) return 0xff87613D;
        if (n.contains("sand") && !n.contains("soul"))
            return n.contains("red") ? 0xffC97D46 : 0xffDFD1A1;
        if (n.contains("gravel")) return 0xff8B8984;
        if (n.contains("deepslate") || n.contains("basalt")) return 0xff55575D;
        if (n.contains("obsidian")) return 0xff2B223C;
        if (n.contains("netherrack") || n.contains("nether_brick")) return 0xff884B49;
        if (n.contains("soul")) return 0xff665143;
        if (n.contains("crimson")) return 0xff974656;
        if (n.contains("warped")) return 0xff419E96;
        if (n.contains("end_stone") || n.contains("end_brick")) return 0xffD6D6A2;
        if (n.contains("purpur") || n.contains("chorus")) return 0xffB18DAF;
        if (n.contains("prismarine")) return 0xff6BAFA4;
        if (n.contains("glass")) return 0xffB0CCD0;
        if (n.contains("glowstone") || n.contains("lantern") || n.contains("torch"))
            return 0xffE2CC80;
        if (n.contains("amethyst")) return 0xffAC85C6;
        if (n.contains("log")
                || n.contains("wood")
                || n.contains("plank")
                || n.contains("chest")
                || n.contains("barrel")) {
            if (n.contains("birch")) return 0xffD8CC9C;
            if (n.contains("spruce") || n.contains("dark_oak")) return 0xff77573A;
            if (n.contains("cherry")) return 0xffD5AAA5;
            return 0xffAA8958;
        }
        String[] colors = {
            "white",
            "orange",
            "magenta",
            "light_blue",
            "yellow",
            "lime",
            "pink",
            "gray",
            "light_gray",
            "cyan",
            "purple",
            "blue",
            "brown",
            "green",
            "red",
            "black"
        };
        int[] rgb = {
            0xffDEDED8,
            0xffD68A44,
            0xffB565B9,
            0xff76B4D7,
            0xffDFC763,
            0xffCC9052,
            0xffD79BAF,
            0xff67686A,
            0xffAAA9A0,
            0xff4C9EAB,
            0xff8D5CB4,
            0xff4D65B1,
            0xff8A6547,
            0xff8B6B4A,
            0xffB65D53,
            0xff33363B
        };
        for (int i = 0; i < colors.length; i++) if (n.contains(colors[i] + "_")) return rgb[i];
        if (n.contains("brick")) return 0xffA87867;
        if (n.contains("stone")
                || n.contains("andesite")
                || n.contains("diorite")
                || n.contains("tuff")) return 0xff91918A;
        return 0xff96918A;
    }

    public static int foliage(int biome) {
        return switch (biome) {
            case 2, 17, 130 -> 0xffB8AC66;
            case 6, 134 -> 0xff947351;
            case 7, 24, 0, 10 -> 0xff9F7B55;
            case 12, 13, 26, 140 -> 0xffAF9B87;
            case 5, 19, 30, 31, 32, 33, 160, 161 -> 0xff9E866D;
            case 21, 22, 23, 149, 151, 168, 169 -> 0xffAA7640;
            case 35, 36, 163, 164 -> 0xffAAA65C;
            case 37, 38, 39, 165, 166, 167 -> 0xffA18D56;
            default -> 0xffAF8152;
        };
    }

    public static int biome(int id) {
        if (id < 0) return 0x00000000;
        float hue = (float) ((id * .61803398875) % 1) * 360;
        return Color.HSVToColor(new float[] {hue, .39f, .86f});
    }

    public static String biomeName(int id) {
        return switch (id) {
            case -1 -> "Unavailable";
            case 0 -> "Ocean";
            case 1 -> "Plains";
            case 2 -> "Desert";
            case 3 -> "Windswept hills";
            case 4 -> "Forest";
            case 5 -> "Taiga";
            case 6 -> "Swamp";
            case 7 -> "River";
            case 8 -> "Nether wastes";
            case 9 -> "The End";
            case 10 -> "Frozen ocean";
            case 11 -> "Frozen river";
            case 12 -> "Snowy plains";
            case 14 -> "Mushroom fields";
            case 16 -> "Beach";
            case 21 -> "Jungle";
            case 24 -> "Deep ocean";
            case 27 -> "Birch forest";
            case 29 -> "Dark forest";
            case 30 -> "Snowy taiga";
            case 35 -> "Savanna";
            case 37 -> "Badlands";
            case 178 -> "Soul sand valley";
            case 179 -> "Crimson forest";
            case 180 -> "Warped forest";
            case 181 -> "Basalt deltas";
            default -> "Biome " + id;
        };
    }

    public static int shade(int color, float multiplier) {
        multiplier = Math.max(.15f, Math.min(1.8f, multiplier));
        return Color.argb(
                Color.alpha(color),
                Math.min(255, (int) (Color.red(color) * multiplier)),
                Math.min(255, (int) (Color.green(color) * multiplier)),
                Math.min(255, (int) (Color.blue(color) * multiplier)));
    }

    public static int emission(String id) {
        if (id.contains("soul_torch") || id.contains("soul_lantern") || id.contains("soul_fire"))
            return 10;
        if (id.contains("redstone_torch")) return 7;
        if (id.contains("torch")) return 14;
        if (id.contains("glow_lichen")) return 7;
        if (id.contains("glowstone")
                || id.contains("sea_lantern")
                || id.contains("shroomlight")
                || id.contains("lava")
                || id.contains("beacon")
                || id.contains("lantern")
                || id.contains("froglight")
                || id.contains("jack_o_lantern")
                || id.contains("fire")) return 15;
        if (id.contains("magma")) return 3;
        return 0;
    }
}
