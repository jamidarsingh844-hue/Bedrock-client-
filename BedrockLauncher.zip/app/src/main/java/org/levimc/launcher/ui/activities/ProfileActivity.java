package org.levimc.launcher.ui.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;

import org.levimc.launcher.R;
import org.levimc.launcher.ui.views.Skin3DView;
import org.levimc.launcher.util.CosmeticsStore;

public class ProfileActivity extends BaseActivity {

    private Skin3DView preview;
    private TextView status;

    private final ActivityResultLauncher<String[]> skinPicker =
            registerForActivityResult(new ActivityResultContracts.OpenDocument(), uri -> {
                if (uri == null) return;
                if (CosmeticsStore.saveSkin(this, uri)) {
                    refresh();
                    Toast.makeText(this, "Skin applied", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Use a PNG skin of size 64x64 or 64x32", Toast.LENGTH_LONG).show();
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        preview = findViewById(R.id.profile_preview);
        status = findViewById(R.id.profile_status);
        TextView change = findViewById(R.id.profile_btn_change);
        TextView reset = findViewById(R.id.profile_btn_reset);

        findViewById(R.id.profile_btn_4d).setOnClickListener(v ->
                startActivity(new Intent(this, SkinFinderActivity.class)));
        change.setOnClickListener(v -> skinPicker.launch(new String[]{"image/png"}));
        reset.setOnClickListener(v -> {
            CosmeticsStore.clearSkin(this);
            refresh();
        });
        refresh();
    }

    private void refresh() {
        preview.setSkin(CosmeticsStore.loadSkin(this));
        status.setText(CosmeticsStore.hasCustomSkin(this) ? "Using your custom skin" : "Using the starting skin");
    }
}
