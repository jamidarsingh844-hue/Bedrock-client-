package org.levimc.launcher.core.mods.inbuilt.overlay;

import android.app.Activity;
import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageButton;

import org.levimc.launcher.R;
import org.levimc.launcher.core.mods.inbuilt.model.ModIds;
import org.levimc.launcher.preloader.PreloaderInput;

/**
 * Bridge Assist: while switched on, taps the centre of the screen a few times per second
 * (only while you are in a world, never in menus), which places the block you hold at the crosshair.
 */
public class BridgeAssistOverlay extends BaseOverlayButton {
    private static final int POINTER_ID = 31;
    private static final long INTERVAL_MS = 130L;
    private static final long HOLD_MS = 35L;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean isActive = false;

    private final Runnable tapRunnable = new Runnable() {
        @Override
        public void run() {
            if (!isActive) return;
            try {
                if (PreloaderInput.isHudScreenOpen() && !PreloaderInput.isPauseMenuOpen()) {
                    sendTap();
                }
            } catch (Throwable ignored) {
            }
            handler.postDelayed(this, INTERVAL_MS);
        }
    };

    public BridgeAssistOverlay(Activity activity) {
        super(activity);
    }

    @Override
    protected String getModId() {
        return ModIds.BRIDGE_ASSIST;
    }

    @Override
    protected int getIconResource() {
        return isActive ? R.drawable.ic_bridge_pressed : R.drawable.ic_bridge_normal;
    }

    @Override
    protected void onButtonClick() {
        isActive = !isActive;
        handler.removeCallbacks(tapRunnable);
        if (isActive) handler.post(tapRunnable);
        updateButtonState();
    }

    private void sendTap() {
        View decor = activity.getWindow().getDecorView();
        final float x = decor.getWidth() / 2f;
        final float y = decor.getHeight() / 2f;
        PreloaderInput.onTouch(MotionEvent.ACTION_DOWN, POINTER_ID, x, y);
        handler.postDelayed(() -> PreloaderInput.onTouch(MotionEvent.ACTION_UP, POINTER_ID, x, y), HOLD_MS);
    }

    private void updateButtonState() {
        if (overlayView != null) {
            ImageButton btn = overlayView.findViewById(R.id.mod_overlay_button);
            if (btn != null) {
                btn.setAlpha(getButtonOpacity());
                btn.setImageResource(isActive ? R.drawable.ic_bridge_pressed : R.drawable.ic_bridge_normal);
            }
        }
    }

    @Override
    public void hide() {
        isActive = false;
        handler.removeCallbacks(tapRunnable);
        updateButtonState();
        super.hide();
    }
}
