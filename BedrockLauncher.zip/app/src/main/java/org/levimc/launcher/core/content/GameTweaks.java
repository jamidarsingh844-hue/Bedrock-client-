package org.levimc.launcher.core.content;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;
import org.levimc.launcher.core.mods.inbuilt.manager.InbuiltModManager;
import org.levimc.launcher.core.mods.inbuilt.model.ModIds;
import org.levimc.launcher.core.versions.GameVersion;
import org.levimc.launcher.util.LauncherStorage;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** Applies the Fullbright and Ore Hologram inbuilt mods to the game's data folders before launch. */
public final class GameTweaks {
    private static final String TAG = "GameTweaks";
    private static final String PREFS = "game_tweaks";
    private static final String GAMMA_KEY = "gfx_gamma";
    private static final String FULLBRIGHT_GAMMA = "8.000000";
    private static final String PACK_FOLDER = "Ore_Hologram";
    private static final String PACK_ID = "b8f5a8f2-3c1d-4e7a-9d52-6a1c0f4e7b11";
    private static final String PACK_ASSET = "ore_hologram.zip";

    private GameTweaks() {}

    public static List<String> apply(Context context, GameVersion version) {
        List<String> log = new ArrayList<>();
        if (version == null) return log;
        InbuiltModManager mods = InbuiltModManager.getInstance(context);
        boolean fullbright = mods.resolveInbuiltModEnabled(ModIds.FULLBRIGHT, false);
        boolean ores = mods.resolveInbuiltModEnabled(ModIds.ORE_HOLOGRAM, false);
        for (boolean external : new boolean[]{false, true}) {
            try {
                File gameData = LauncherStorage.getStorageGameDataDir(
                        context, version.getStorageProfileId(), version.versionIsolation, external);
                if (gameData == null) continue;
                applyFullbright(context, gameData, fullbright, log);
                applyOreHologram(context, gameData, ores, log);
            } catch (Throwable t) {
                Log.w(TAG, "apply failed (external=" + external + "): " + t.getMessage());
                log.add("Tweak error: " + t.getClass().getSimpleName() + " " + t.getMessage());
            }
        }
        return log;
    }

    private static String shortPath(File f) {
        String p = f.getAbsolutePath();
        return p.length() > 60 ? "..." + p.substring(p.length() - 57) : p;
    }

    // ---- fullbright: raise gfx_gamma in options.txt ---------------------------------

    private static void applyFullbright(Context context, File gameData, boolean enabled, List<String> log) throws Exception {
        File options = new File(new File(gameData, "minecraftpe"), "options.txt");
        SharedPreferences sp = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String key = "prev_gamma_" + options.getAbsolutePath();

        List<String> lines = new ArrayList<>();
        if (options.exists()) {
            try (BufferedReader r = new BufferedReader(new FileReader(options))) {
                String line;
                while ((line = r.readLine()) != null) lines.add(line);
            }
        }
        int idx = -1;
        String current = "";
        for (int i = 0; i < lines.size(); i++) {
            if (lines.get(i).startsWith(GAMMA_KEY + ":")) {
                idx = i;
                current = lines.get(i).substring(GAMMA_KEY.length() + 1).trim();
                break;
            }
        }

        if (enabled) {
            if (!sp.contains(key)) sp.edit().putString(key, current).apply();
            String entry = GAMMA_KEY + ":" + FULLBRIGHT_GAMMA;
            if (idx >= 0) lines.set(idx, entry); else lines.add(entry);
            writeLines(options, lines);
            log.add("Fullbright ON: gfx_gamma set (was '" + current + "') in " + shortPath(options));
        } else if (sp.contains(key)) {
            String original = sp.getString(key, "");
            if (idx >= 0) {
                if (original.isEmpty()) lines.remove(idx);
                else lines.set(idx, GAMMA_KEY + ":" + original);
                writeLines(options, lines);
            }
            sp.edit().remove(key).apply();
            log.add("Fullbright OFF: brightness restored in " + shortPath(options));
        }
    }

    private static void writeLines(File file, List<String> lines) throws Exception {
        File parent = file.getParentFile();
        if (parent != null && !parent.exists()) parent.mkdirs();
        try (FileWriter w = new FileWriter(file, false)) {
            for (String l : lines) w.write(l + "\n");
        }
    }

    // ---- ore hologram: install pack + activate in global_resource_packs.json ---------

    private static void applyOreHologram(Context context, File gameData, boolean enabled, List<String> log) throws Exception {
        File pack = new File(new File(gameData, "resource_packs"), PACK_FOLDER);
        File globals = new File(new File(gameData, "minecraftpe"), "global_resource_packs.json");

        if (enabled) {
            if (!new File(pack, "manifest.json").exists()) extract(context, pack);
            writeGlobalPacks(globals, true);
            log.add("Ore Hologram ON: pack in " + shortPath(pack) + ", activated");
        } else {
            if (pack.exists()) deleteRecursive(pack);
            if (globals.exists()) writeGlobalPacks(globals, false);
        }
    }

    private static void writeGlobalPacks(File file, boolean include) throws Exception {
        JSONArray existing = new JSONArray();
        if (file.exists()) {
            StringBuilder sb = new StringBuilder();
            try (BufferedReader r = new BufferedReader(new FileReader(file))) {
                String line;
                while ((line = r.readLine()) != null) sb.append(line);
            }
            try {
                existing = new JSONArray(sb.toString());
            } catch (Exception ignored) {
                existing = new JSONArray();
            }
        }
        JSONArray out = new JSONArray();
        if (include) {
            JSONObject mine = new JSONObject();
            mine.put("pack_id", PACK_ID);
            mine.put("version", new JSONArray().put(1).put(0).put(0));
            out.put(mine);
        }
        for (int i = 0; i < existing.length(); i++) {
            JSONObject o = existing.optJSONObject(i);
            if (o == null || PACK_ID.equals(o.optString("pack_id"))) continue;
            out.put(o);
        }
        File parent = file.getParentFile();
        if (parent != null && !parent.exists()) parent.mkdirs();
        try (FileWriter w = new FileWriter(file, false)) {
            w.write(out.toString());
        }
    }

    private static void extract(Context context, File dest) throws Exception {
        if (!dest.exists() && !dest.mkdirs()) throw new java.io.IOException("Cannot create " + dest);
        String destPath = dest.getCanonicalPath() + File.separator;
        byte[] buf = new byte[16384];
        try (InputStream raw = context.getAssets().open(PACK_ASSET);
             ZipInputStream zin = new ZipInputStream(raw)) {
            ZipEntry e;
            while ((e = zin.getNextEntry()) != null) {
                if (e.isDirectory()) continue;
                File out = new File(dest, e.getName());
                if (!out.getCanonicalPath().startsWith(destPath)) continue;
                File parent = out.getParentFile();
                if (parent != null && !parent.exists()) parent.mkdirs();
                try (OutputStream os = new FileOutputStream(out)) {
                    int n;
                    while ((n = zin.read(buf)) > 0) os.write(buf, 0, n);
                }
            }
        }
    }

    private static void deleteRecursive(File f) {
        File[] kids = f.listFiles();
        if (kids != null) for (File k : kids) deleteRecursive(k);
        f.delete();
    }
}
