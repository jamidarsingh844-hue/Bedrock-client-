package org.levimc.launcher.core.content;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;
import org.levimc.launcher.core.mods.inbuilt.manager.InbuiltModManager;
import org.levimc.launcher.core.mods.inbuilt.model.ModIds;
import org.levimc.launcher.core.versions.GameVersion;
import org.levimc.launcher.util.LauncherStorage;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** Applies the Fullbright and Ore Hologram inbuilt mods to the game's data folders before launch. */
public final class GameTweaks {
    private static final String TAG = "GameTweaks";
    private static final String PREFS = "game_tweaks";
    private static final String GAMMA_KEY = "gfx_gamma";
    private static final String FULLBRIGHT_GAMMA = "8.000000";
    // Bundled packs switched on/off by inbuilt mods. PACK_ID must equal the pack's manifest header uuid,
    // and the version must equal its header version (a newer bundled version re-installs the pack in place).
    private static final String ORE_FOLDER = "Ore_Hologram";
    private static final String ORE_PACK_ID = "b8f5a8f2-3c1d-4e7a-9d52-6a1c0f4e7b11";
    private static final String ORE_ASSET = "ore_hologram.zip";
    private static final String FUNK_FOLDER = "Funk_Music";
    private static final String FUNK_PACK_ID = "7c1e5a3e-4b8d-4f3a-9d2a-1a6f0c9b7e21";
    private static final String FUNK_ASSET = "funk_music.zip";
    private static final int[] PACK_VERSION = {1, 0, 0};

    private GameTweaks() {}

    public static List<String> apply(Context context, GameVersion version) {
        List<String> log = new ArrayList<>();
        if (version == null) return log;
        InbuiltModManager mods = InbuiltModManager.getInstance(context);
        boolean fullbright = mods.resolveInbuiltModEnabled(ModIds.FULLBRIGHT, false);
        boolean ores = mods.resolveInbuiltModEnabled(ModIds.ORE_HOLOGRAM, false);
        boolean funk = mods.resolveInbuiltModEnabled(ModIds.FUNK_MUSIC, false);
        for (boolean external : new boolean[]{false, true}) {
            File gameData;
            try {
                gameData = LauncherStorage.getStorageGameDataDir(
                        context, version.getStorageProfileId(), version.versionIsolation, external);
            } catch (Throwable t) {
                logError(log, "storage", external, t);
                continue;
            }
            if (gameData == null) continue;
            // Each tweak runs on its own so one failure never blocks the others.
            try {
                applyFullbright(context, gameData, fullbright, log);
            } catch (Throwable t) {
                logError(log, "Fullbright", external, t);
            }
            try {
                applyBundledPack(context, gameData, "Ore Hologram", ORE_FOLDER, ORE_PACK_ID, ORE_ASSET, ores, log);
            } catch (Throwable t) {
                logError(log, "Ore Hologram", external, t);
            }
            try {
                applyBundledPack(context, gameData, "Funk Music", FUNK_FOLDER, FUNK_PACK_ID, FUNK_ASSET, funk, log);
            } catch (Throwable t) {
                logError(log, "Funk Music", external, t);
            }
        }
        return log;
    }

    private static void logError(List<String> log, String what, boolean external, Throwable t) {
        Log.w(TAG, what + " failed (external=" + external + "): " + t.getMessage());
        log.add("Tweak error (" + what + "): " + t.getClass().getSimpleName() + " " + t.getMessage());
    }

    private static String shortPath(File f) {
        String p = f.getAbsolutePath();
        return p.length() > 60 ? "..." + p.substring(p.length() - 57) : p;
    }

    // ---- fullbright: raise gfx_gamma in options.txt ---------------------------------

    private static void applyFullbright(Context context, File gameData, boolean enabled, List<String> log) throws Exception {
        File options = new File(new File(gameData, "minecraftpe"), "options.txt");
        SharedPreferences sp = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String key = "prev_gamma_" + options.getAbsolutePath();

        List<String> lines = new ArrayList<>();
        if (options.exists()) {
            try (BufferedReader r = new BufferedReader(new FileReader(options))) {
                String line;
                while ((line = r.readLine()) != null) lines.add(line);
            }
        }
        int idx = -1;
        String current = "";
        for (int i = 0; i < lines.size(); i++) {
            if (lines.get(i).startsWith(GAMMA_KEY + ":")) {
                idx = i;
                current = lines.get(i).substring(GAMMA_KEY.length() + 1).trim();
                break;
            }
        }

        if (enabled) {
            if (!sp.contains(key)) sp.edit().putString(key, current).apply();
            String entry = GAMMA_KEY + ":" + FULLBRIGHT_GAMMA;
            if (idx >= 0) lines.set(idx, entry); else lines.add(entry);
            writeLines(options, lines);
            log.add("Fullbright ON: gfx_gamma set (was '" + current + "') in " + shortPath(options));
        } else if (sp.contains(key)) {
            String original = sp.getString(key, "");
            if (idx >= 0) {
                if (original.isEmpty()) lines.remove(idx);
                else lines.set(idx, GAMMA_KEY + ":" + original);
                writeLines(options, lines);
            }
            sp.edit().remove(key).apply();
            log.add("Fullbright OFF: brightness restored in " + shortPath(options));
        }
    }

    private static void writeLines(File file, List<String> lines) throws Exception {
        File parent = file.getParentFile();
        if (parent != null && !parent.exists()) parent.mkdirs();
        try (FileWriter w = new FileWriter(file, false)) {
            for (String l : lines) w.write(l + "\n");
        }
    }

    // ---- ore hologram: install pack + activate in global_resource_packs.json ---------

    /**
     * ON: install the bundled pack (re-installed in place when the bundled version changed) and activate it
     * in global_resource_packs.json. OFF: remove it and take it out of the active list.
     */
    private static void applyBundledPack(Context context, File gameData, String label, String folder,
                                         String packId, String asset, boolean enabled,
                                         List<String> log) throws Exception {
        File pack = new File(new File(gameData, "resource_packs"), folder);
        File globals = new File(new File(gameData, "minecraftpe"), "global_resource_packs.json");

        if (enabled) {
            if (!versionMatches(pack)) {
                if (pack.exists()) deleteRecursive(pack);
                extract(context, pack, asset);
            }
            writeGlobalPacks(globals, packId, true);
            log.add(label + " ON: pack in " + shortPath(pack) + ", activated");
        } else {
            if (pack.exists()) deleteRecursive(pack);
            if (globals.exists()) writeGlobalPacks(globals, packId, false);
        }
    }

    /** True when the installed pack has a manifest whose header version equals PACK_VERSION. */
    private static boolean versionMatches(File pack) {
        File manifest = new File(pack, "manifest.json");
        if (!manifest.isFile()) return false;
        try (BufferedReader r = new BufferedReader(new FileReader(manifest))) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line).append('\n');
            JSONArray v = new JSONObject(sb.toString()).getJSONObject("header").getJSONArray("version");
            if (v.length() != PACK_VERSION.length) return false;
            for (int i = 0; i < PACK_VERSION.length; i++) {
                if (v.getInt(i) != PACK_VERSION[i]) return false;
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private static void writeGlobalPacks(File file, String packId, boolean include) throws Exception {
        JSONArray existing = new JSONArray();
        if (file.exists()) {
            StringBuilder sb = new StringBuilder();
            try (BufferedReader r = new BufferedReader(new FileReader(file))) {
                String line;
                while ((line = r.readLine()) != null) sb.append(line);
            }
            try {
                existing = new JSONArray(sb.toString());
            } catch (Exception ignored) {
                existing = new JSONArray();
            }
        }
        JSONArray out = new JSONArray();
        if (include) {
            JSONObject mine = new JSONObject();
            mine.put("pack_id", packId);
            JSONArray ver = new JSONArray();
            for (int part : PACK_VERSION) ver.put(part);
            mine.put("version", ver);
            out.put(mine);
        }
        for (int i = 0; i < existing.length(); i++) {
            JSONObject o = existing.optJSONObject(i);
            if (o == null || packId.equals(o.optString("pack_id"))) continue;
            out.put(o);
        }
        File parent = file.getParentFile();
        if (parent != null && !parent.exists()) parent.mkdirs();
        try (FileWriter w = new FileWriter(file, false)) {
            w.write(out.toString());
        }
    }

    private static void extract(Context context, File dest, String asset) throws Exception {
        if (!dest.exists() && !dest.mkdirs()) throw new java.io.IOException("Cannot create " + dest);
        String destPath = dest.getCanonicalPath() + File.separator;
        byte[] buf = new byte[16384];
        try (InputStream raw = context.getAssets().open(asset);
             ZipInputStream zin = new ZipInputStream(raw)) {
            ZipEntry e;
            while ((e = zin.getNextEntry()) != null) {
                if (e.isDirectory()) continue;
                File out = new File(dest, e.getName());
                if (!out.getCanonicalPath().startsWith(destPath)) continue;
                File parent = out.getParentFile();
                if (parent != null && !parent.exists()) parent.mkdirs();
                try (OutputStream os = new FileOutputStream(out)) {
                    int n;
                    while ((n = zin.read(buf)) > 0) os.write(buf, 0, n);
                }
            }
        }
    }

    private static void deleteRecursive(File f) {
        File[] kids = f.listFiles();
        if (kids != null) for (File k : kids) deleteRecursive(k);
        f.delete();
    }
}
