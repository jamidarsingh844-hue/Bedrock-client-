package org.levimc.launcher.util;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

/** Stores the skin the player picked inside the launcher profile. */
public final class CosmeticsStore {

    private CosmeticsStore() {}

    private static File skinFile(Context c) {
        File d = new File(c.getFilesDir(), "cosmetics");
        if (!d.exists()) d.mkdirs();
        return new File(d, "skin.png");
    }

    /** Returns the saved skin, or null when the built-in starting skin should be used. */
    public static Bitmap loadSkin(Context c) {
        File f = skinFile(c);
        if (!f.exists()) return null;
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inScaled = false;
        return BitmapFactory.decodeFile(f.getAbsolutePath(), o);
    }

    public static boolean hasCustomSkin(Context c) {
        return skinFile(c).exists();
    }

    /** Accepts 64x64, 64x32 and HD multiples (128x128, 128x64 ...). */
    public static boolean saveSkin(Context c, Uri uri) {
        try (InputStream in = c.getContentResolver().openInputStream(uri)) {
            if (in == null) return false;
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inScaled = false;
            Bitmap b = BitmapFactory.decodeStream(in, null, o);
            if (b == null) return false;
            int w = b.getWidth();
            int h = b.getHeight();
            boolean ok = w % 64 == 0 && (h == w || h * 2 == w);
            if (!ok) return false;
            try (FileOutputStream out = new FileOutputStream(skinFile(c))) {
                b.compress(Bitmap.CompressFormat.PNG, 100, out);
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static void clearSkin(Context c) {
        File f = skinFile(c);
        if (f.exists()) f.delete();
    }
}
