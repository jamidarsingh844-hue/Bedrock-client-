package org.levimc.launcher.ui.activities;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import org.json.JSONObject;
import org.levimc.launcher.R;

import java.io.File;
import java.io.InputStream;
import java.util.ArrayDeque;
import java.util.Enumeration;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/** Scans the phone's storage for skin packs (.mcpack / .zip) and imports the tapped one into the game. */
public class SkinFinderActivity extends BaseActivity {

    public static final String EXTRA_IMPORT_PATH = "import_path";

    private LinearLayout list;
    private TextView status;
    private TextView actionBtn;
    private volatile boolean scanning;
    private volatile boolean destroyed;
    private boolean scannedOnce;
    private int found;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(10), dp(16), dp(10));
        root.setBackgroundColor(ContextCompat.getColor(this, R.color.background));

        TextView title = new TextView(this);
        title.setText("Skin Finder");
        title.setTextSize(22);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(ContextCompat.getColor(this, R.color.on_surface));
        root.addView(title);

        status = new TextView(this);
        status.setTextSize(13);
        status.setTextColor(ContextCompat.getColor(this, R.color.text_secondary));
        status.setPadding(0, dp(4), 0, dp(8));
        root.addView(status);

        actionBtn = new TextView(this);
        actionBtn.setGravity(Gravity.CENTER);
        actionBtn.setTextSize(15);
        actionBtn.setTypeface(Typeface.DEFAULT_BOLD);
        actionBtn.setTextColor(ContextCompat.getColor(this, R.color.white));
        actionBtn.setBackgroundResource(R.drawable.bg_launch_button);
        actionBtn.setClickable(true);
        actionBtn.setFocusable(true);
        root.addView(actionBtn, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(46)));

        ScrollView scroll = new ScrollView(this);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(list);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f);
        sp.topMargin = dp(10);
        root.addView(scroll, sp);

        setContentView(root);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (hasAccess()) {
            actionBtn.setText("Scan again");
            actionBtn.setOnClickListener(v -> startScan());
            if (!scannedOnce) startScan();
        } else {
            status.setText("Allow access to all files so the launcher can look for skin packs on your phone.");
            actionBtn.setText("Allow file access");
            actionBtn.setOnClickListener(v -> requestAccess());
        }
    }

    @Override
    protected void onDestroy() {
        destroyed = true;
        super.onDestroy();
    }

    private boolean hasAccess() {
        if (Build.VERSION.SDK_INT >= 30) return Environment.isExternalStorageManager();
        return ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void requestAccess() {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
            } catch (Exception e) {
                startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
            }
        } else {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 7);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (hasAccess()) startScan();
    }

    private void startScan() {
        if (scanning) return;
        scanning = true;
        scannedOnce = true;
        found = 0;
        list.removeAllViews();
        status.setText("Scanning your phone for skin packs...");
        new Thread(() -> {
            File root = Environment.getExternalStorageDirectory();
            ArrayDeque<File> stack = new ArrayDeque<>();
            stack.push(root);
            while (!stack.isEmpty() && !destroyed) {
                File dir = stack.pop();
                File[] kids = dir.listFiles();
                if (kids == null) continue;
                for (File f : kids) {
                    String n = f.getName();
                    if (f.isDirectory()) {
                        if (n.startsWith(".")) continue;
                        if (dir.equals(root) && n.equals("Android")) continue;
                        stack.push(f);
                    } else {
                        String l = n.toLowerCase(Locale.ROOT);
                        if ((l.endsWith(".mcpack") || l.endsWith(".zip") || l.endsWith(".mcaddon"))
                                && f.length() > 0 && f.length() < 400L * 1024 * 1024) {
                            String packName = inspect(f);
                            if (packName != null) runOnUiThread(() -> addRow(packName, f));
                        }
                    }
                }
            }
            runOnUiThread(() -> {
                scanning = false;
                status.setText(found == 0
                        ? "No skin packs found. Download a .mcpack skin pack, then scan again."
                        : found + " skin pack(s) found. Tap one to import it into the game.");
            });
        }).start();
    }

    /** Returns the pack name when the archive holds a skin pack, otherwise null. */
    private String inspect(File f) {
        try (ZipFile zf = new ZipFile(f)) {
            String fallback = null;
            Enumeration<? extends ZipEntry> en = zf.entries();
            while (en.hasMoreElements()) {
                ZipEntry e = en.nextElement();
                if (e.isDirectory()) continue;
                String name = e.getName().toLowerCase(Locale.ROOT);
                int slashes = name.length() - name.replace("/", "").length();
                if (slashes > 1) continue;
                if (name.endsWith("skins.json")) {
                    fallback = stripExt(f.getName());
                } else if (name.endsWith("manifest.json")) {
                    String text = readSmall(zf, e);
                    if (text != null && text.contains("skin_pack")) {
                        try {
                            JSONObject h = new JSONObject(text).optJSONObject("header");
                            String nm = h != null ? h.optString("name", "") : "";
                            return nm.isEmpty() || nm.startsWith("pack.") ? stripExt(f.getName()) : nm;
                        } catch (Exception ex) {
                            return stripExt(f.getName());
                        }
                    }
                }
            }
            return fallback;
        } catch (Exception e) {
            return null;
        }
    }

    private String readSmall(ZipFile zf, ZipEntry e) {
        try (InputStream in = zf.getInputStream(e)) {
            byte[] buf = new byte[65536];
            int total = 0, r;
            while (total < buf.length && (r = in.read(buf, total, buf.length - total)) > 0) total += r;
            return new String(buf, 0, total, "UTF-8");
        } catch (Exception ex) {
            return null;
        }
    }

    private static String stripExt(String n) {
        int i = n.lastIndexOf('.');
        return i > 0 ? n.substring(0, i) : n;
    }

    private void addRow(String packName, File file) {
        found++;
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setBackgroundResource(R.drawable.bg_tile);
        row.setPadding(dp(18), dp(12), dp(14), dp(12));
        row.setClickable(true);
        row.setFocusable(true);

        TextView t = new TextView(this);
        t.setText(packName);
        t.setTextSize(16);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setTextColor(ContextCompat.getColor(this, R.color.on_surface));
        row.addView(t);

        TextView p = new TextView(this);
        p.setText(file.getAbsolutePath() + "  -  " + (file.length() / 1024) + " KB");
        p.setTextSize(11);
        p.setTextColor(ContextCompat.getColor(this, R.color.text_secondary));
        row.addView(p);

        row.setOnClickListener(v -> {
            Intent i = new Intent(this, ContentManagementActivity.class);
            i.putExtra(EXTRA_IMPORT_PATH, file.getAbsolutePath());
            startActivity(i);
        });

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(8);
        list.addView(row, lp);
        status.setText(found + " skin pack(s) found so far...");
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
