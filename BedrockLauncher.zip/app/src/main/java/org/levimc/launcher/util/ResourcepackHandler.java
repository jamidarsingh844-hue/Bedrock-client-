package org.levimc.launcher.util;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.widget.Button;
import android.widget.ProgressBar;

import org.levimc.launcher.R;
import org.levimc.launcher.core.minecraft.MinecraftImportIntents;
import org.levimc.launcher.core.minecraft.MinecraftLauncher;
import org.levimc.launcher.core.versions.GameVersion;
import org.levimc.launcher.core.versions.VersionManager;
import org.levimc.launcher.ui.dialogs.CustomAlertDialog;

import java.util.concurrent.ExecutorService;

public class ResourcepackHandler {

    private final Activity activity;
    private final MinecraftLauncher minecraftLauncher;
    private final ExecutorService executor;

    public ResourcepackHandler(Activity activity, MinecraftLauncher minecraftLauncher,
                               ExecutorService executor) {
        this.activity = activity;
        this.minecraftLauncher = minecraftLauncher;
        this.executor = executor;
    }

    public void checkIntentForResourcepack() {
        Intent intent = activity.getIntent();
        if (!MinecraftImportIntents.isMinecraftResourceIntent(activity, intent)) {
            return;
        }
        if (MinecraftImportIntents.forwardToRunningMinecraft(activity, intent)) {
            return;
        }

        Uri data = intent.getData();
        if (data != null && isPackFile(data)) {
            // Packs are imported by the launcher itself (reliable, shows a result).
            // Handing them to the game's own importer can stop at "Import started".
            importPackDirectly(data);
            return;
        }
        if (data != null) {
            String displayPath = data.getPath() != null ? data.getPath() : data.toString();
            new CustomAlertDialog(activity)
                    .setTitleText(activity.getString(R.string.content_detected_title))
                    .setMessage(activity.getString(R.string.content_detected_message, displayPath))
                    .setPositiveButton(activity.getString(R.string.launch_now), (d) -> launchMinecraft(intent))
                    .setNegativeButton(activity.getString(R.string.launch_later), null)
                    .show();
        }
    }

    private boolean isPackFile(Uri uri) {
        String name = null;
        if ("content".equals(uri.getScheme())) {
            try (android.database.Cursor c = activity.getContentResolver().query(uri, null, null, null, null)) {
                if (c != null && c.moveToFirst()) {
                    int idx = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                    if (idx >= 0) name = c.getString(idx);
                }
            } catch (Exception ignored) {
            }
        }
        if (name == null) name = uri.getLastPathSegment();
        if (name == null) return false;
        String lower = name.toLowerCase(java.util.Locale.ROOT);
        return lower.endsWith(".mcpack") || lower.endsWith(".mcaddon");
    }

    private void importPackDirectly(Uri uri) {
        // Consume the intent so this file is not imported again on the next resume.
        activity.setIntent(new Intent(activity, activity.getClass()));

        GameVersion version = VersionManager.get(activity).getSelectedVersion();
        if (version == null) {
            new CustomAlertDialog(activity)
                    .setTitleText(activity.getString(R.string.dialog_title_no_version))
                    .setMessage(activity.getString(R.string.dialog_message_no_version))
                    .setPositiveButton(activity.getString(R.string.dialog_positive_ok), null)
                    .show();
            return;
        }

        java.io.File base = org.levimc.launcher.core.content.PendingPackManager.contentGameDataDir(activity, version);
        org.levimc.launcher.ui.dialogs.LoadingDialog loading = new org.levimc.launcher.ui.dialogs.LoadingDialog(activity);
        loading.show();
        loading.setMessage(activity.getString(R.string.importing_content));

        org.levimc.launcher.core.content.ContentImporter importer =
                new org.levimc.launcher.core.content.ContentImporter(activity);
        importer.importContent(java.util.Collections.singletonList(uri),
                new java.io.File(base, "resource_packs"),
                new java.io.File(base, "behavior_packs"),
                new java.io.File(base, "skin_packs"),
                new java.io.File(base, "minecraftWorlds"),
                new org.levimc.launcher.core.content.ContentImporter.ImportCallback() {
                    @Override
                    public void onSuccess(String message) {
                        finish(message);
                    }

                    @Override
                    public void onError(String error) {
                        finish(error);
                    }

                    @Override
                    public void onProgress(int progress) {
                    }

                    private void finish(String message) {
                        activity.runOnUiThread(() -> {
                            importer.shutdown();
                            if (loading.isShowing()) loading.dismiss();
                            if (activity.isFinishing() || activity.isDestroyed()) return;
                            try {
                                org.levimc.launcher.core.content.ContentManager.getInstance(activity).refreshContent();
                            } catch (Throwable ignored) {
                            }
                            new CustomAlertDialog(activity)
                                    .setTitleText(activity.getString(R.string.import_content_title))
                                    .setMessage(message)
                                    .setPositiveButton(activity.getString(R.string.dialog_positive_ok), null)
                                    .show();
                        });
                    }
                });
    }

    private void launchMinecraft(Intent intent) {
        executor.execute(() -> {
            VersionManager versionManager = VersionManager.get(activity);
            GameVersion currentVersion = versionManager.getSelectedVersion();

            minecraftLauncher.launch(intent, currentVersion);
            activity.runOnUiThread(() -> {
            });
        });
    }
}
