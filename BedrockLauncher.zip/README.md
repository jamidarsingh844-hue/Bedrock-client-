# Bedrock Launcher

Minecraft Bedrock launcher for Android, based on LeviLaunchroid (LeviMC Team, Apache 2.0).
See NOTICE and LICENSE. Not affiliated with Mojang or Microsoft; you need a licensed copy of Minecraft.

## Building
Native code needs the two git submodules (preloader, libHttpClient), and Gradle needs a
`google-services.json` (a placeholder is fine for local builds). See `.github/workflows/build.yml`.
